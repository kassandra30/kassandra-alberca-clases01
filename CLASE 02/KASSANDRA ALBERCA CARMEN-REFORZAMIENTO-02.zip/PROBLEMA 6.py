#PROBLEMA 06
#Calcular la media de 5 datos (floats), cada dato debe estar en una variable y la media también.
# Mostrar el resultado en pantalla y el tipo de dato también mostrarlo.
variable_1 = 12.1
variable_2 = 12.2
variable_3 = 12.3
variable_4 = 12.4
variable_5 = 12.5
media = (variable_1 + variable_2 + variable_3 + variable_4 + variable_5) / 5
print("La media es:", media)
print("Tipo de variable:", type(media))