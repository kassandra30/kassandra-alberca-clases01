#PROBLEMA 05
#Crear un programa que inicia creando un sueldo en una variable, sepamos si es par o impar mediante un mensaje.
# Utilizar módulo y condicional (if).
sueldo = 1234
if sueldo % 2 == 0:
    print(f"El sueldo {sueldo} es PAR")
else:
    print(f"El sueldo {sueldo} es IMPAR")
