#PROBLEMA 10
#Crear un programa que tome un número flotante en una variable con 6 decimales y se imprima de diferentes modos:
#1 decimal
#2 decimales
#4 decimales
numero = 24.34567
print("1 decimal:", f"{numero:.1f}")
print("2 decimales:", f"{numero:.2f}")
print("4 decimales:", f"{numero:.4f}")
