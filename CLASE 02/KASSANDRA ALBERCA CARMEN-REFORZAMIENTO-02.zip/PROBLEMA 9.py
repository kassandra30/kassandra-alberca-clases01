#PROBLEMA 09
#Elevar una base al exponente de 6 (que estará dentro una variable), este número el cual su valor estará asignado a una variable
# Y luego restar este mismo valor multiplicado por dos (usar pow o **). Mostrar el resultado final en pantalla.
base = 5
resultado = ((base**6)-(2*base))
print("El resultado final es:", resultado)
