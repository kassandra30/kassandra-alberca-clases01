#PROBLEMA 02
#Crea una variable tipo int. Luego, multiplica por 10 y restarle el valor de 10.Debes hacer todo esto en dos pasos.
# Finalmente convertirlo a float y mostrar el resultado por pantalla y el tipo de variable también.
numero = 4
resultado = numero * 10
resultado_2 = resultado - 10
float_1 = float(resultado_2)
print("resultado_2:" , resultado_2)
print("Tipo de variable:" , type(float_1))
