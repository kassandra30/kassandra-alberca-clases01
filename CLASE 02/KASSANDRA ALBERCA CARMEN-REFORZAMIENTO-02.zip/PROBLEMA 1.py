# PROBLEMA 01
# El valor de ‘¡HI TuNombre Apellido!’ imprimirlo en consola, el texto
# debe ser un string y deberás guardarlo en una variable llamada mi_saludo.
# Tu nombre completo debe estar en otra variable.
mi_nombre = "Kassandra Nicol Alberca Carmen"
mi_saludo = f"¡Hi {mi_nombre} !"
print(mi_saludo)