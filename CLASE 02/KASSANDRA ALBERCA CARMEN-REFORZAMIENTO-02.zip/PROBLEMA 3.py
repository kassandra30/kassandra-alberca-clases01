#PROBLEMA 03
#Crear una variable tipo string, luego súmala con otra variable tipo int, para esto convertir una de las variables para realizar este procedimiento
# sin errores. Mostrar la suma en pantalla.
string = "90"
int_1 = 1492
suma = int(string) + int_1
print("La suma es:", suma)