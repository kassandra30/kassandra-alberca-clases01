#PROBLEMA 04
#Hallar el volumen de una esfera, cada dato requerido para hallar el volumen debe estar en una variable.
# Mostrar el volumen por pantalla indicándoselo al usuario. Considera a π = 3.14159
pi = 3.14159
radio = 5.5
volumen = (4/3) * pi * (radio**3)
print("Radio de la esfera:", radio)
print("Volumen de la esfera:", round(volumen, 2))
