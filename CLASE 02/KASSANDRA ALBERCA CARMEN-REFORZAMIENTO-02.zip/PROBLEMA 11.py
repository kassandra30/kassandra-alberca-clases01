#PROBLEMA 11
#Identificar qué tipo de dato se obtiene al elevar tu edad con exponente 5 y luego dividirlo por 10.
# Mostrar el resultado de su módulo con 3 en pantalla
edad = 24
operacion = (edad ** 5) / 10
print("Resultado es de:", operacion)
print("Tipo de dato:", type(operacion))


